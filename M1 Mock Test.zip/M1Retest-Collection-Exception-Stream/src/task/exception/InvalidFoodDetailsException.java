package task.exception;

public class InvalidFoodDetailsException extends Exception{
	
	public InvalidFoodDetailsException(String message) {
        super(message);
    }

}
